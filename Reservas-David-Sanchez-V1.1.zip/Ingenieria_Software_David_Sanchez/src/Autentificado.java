import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Autentificado extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Autentificado frame = new Autentificado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Autentificado() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 486, 276);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 139, 139));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel();
		ImageIcon icon = new ImageIcon("FILES/map.png");
		
		lblNewLabel.setIcon(icon);
		add(lblNewLabel);
		lblNewLabel.setText("\u00A1Bienvenido!");;
		lblNewLabel.setFont(new Font("Verdana Pro Cond Light", Font.PLAIN, 33));
		lblNewLabel.setBounds(800, -200, 2000, 2000);
		contentPane.add(lblNewLabel);
		
		
		
		
		JButton btnNewButton = new JButton("Volleyball");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton.setBounds(850, 760, 124, 39);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton1 = new JButton("Futbol");
		btnNewButton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton1.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton1.setBounds(1000, 760, 124, 39);
		contentPane.add(btnNewButton1);
		
		JButton btnNewButton2 = new JButton("tennis");
		btnNewButton2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton2.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton2.setBounds(1150, 760, 124, 39);
		contentPane.add(btnNewButton2);
		
		JButton btnNewButton3 = new JButton("Baloncesto");
		btnNewButton3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton3.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton3.setBounds(1300, 760, 124, 39);
		contentPane.add(btnNewButton3);
		
		JButton btnNewButton4 = new JButton("beisbol");
		btnNewButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton4.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton4.setBounds(850, 1050, 124, 39);
		contentPane.add(btnNewButton4);
		
		JButton btnNewButton5 = new JButton("Hockey sobre ruedas");
		btnNewButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton5.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton5.setBounds(1050, 1050, 124, 39);
		contentPane.add(btnNewButton5);
		
		JButton btnNewButton6 = new JButton("Futbol Americano");
		btnNewButton6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton6.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton6.setBounds(1200, 1050, 124, 39);
		contentPane.add(btnNewButton6);
		
		JButton btnNewButton7 = new JButton("Billar");
		btnNewButton7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton7.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton7.setBounds(1350, 1050, 124, 39);
		contentPane.add(btnNewButton7);
	}

}
