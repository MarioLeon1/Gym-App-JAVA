import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MySQL {
	
	static ArrayList<String> nicks = new ArrayList<String>();
	static ArrayList<String> passwords = new ArrayList<String>();
		
	public static void main(String[] args) {
		
		Conexion conexion = new Conexion();
		Connection con = null;
		Statement stm = null;
		ResultSet rs = null;
		
		try {
			con = conexion.conectar();
			stm = con.createStatement();
			rs = stm.executeQuery("SELECT * FROM usuarios");
			
			while(rs.next()) {
				String nick = rs.getString(1);
				nicks.add(rs.getString(1));
				String password = rs.getString(2);
				passwords.add(rs.getString(2));
				String nombre = rs.getString(3);
				String apellido1 = rs.getString(4);
				String apellido2 = rs.getString(5);
				String ciudad = rs.getString(6);
				String email = rs.getString(7);
				String telefono = rs.getString(8);
				
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	
	public List<String> getNicks(){
		
		MySQL sql = new MySQL();
		sql.main(null);
		return nicks;
	}
	
	public List<String> getPasswords(){
		
		MySQL sql = new MySQL();
		sql.main(null);
		return passwords;
	}

}
