import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Reservas extends JFrame {

	private JPanel contentPane;
	
	//Se recoge la informaci�n de la pista seleccionada en la pantalla anterior
	
	JLabel imagen = new JLabel("");
	JLabel nombrePista = new JLabel("");
	JLabel usuario = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reservas frame = new Reservas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
		
	public Reservas() {
		
		ArrayList<String> horasReservadas = new ArrayList();
		ArrayList<String> pistasReservadas = new ArrayList();
		
		Conexion conexion = new Conexion();
		Connection con = null;
		Statement stm = null;
		ResultSet rs = null;

		try {
		con = conexion.conectar();
		stm = con.createStatement();
		rs = stm.executeQuery("SELECT * FROM reservas");
		
		while(rs.next()) {
			horasReservadas.add(rs.getString(1));
			pistasReservadas.add(rs.getString(2));
		}
		
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		System.out.println(horasReservadas);
		System.out.println(pistasReservadas);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 901, 462);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(new Color(255, 153, 51));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("SELECCIONE LA HORA DESEADA:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Radian", Font.BOLD, 42));
		lblNewLabel_1.setBounds(41, 25, 684, 53);
		contentPane.add(lblNewLabel_1);
		
		imagen.setBounds(10, 71, 434, 276);
		contentPane.add(imagen);
		
		nombrePista.setForeground(Color.WHITE);
		nombrePista.setFont(new Font("Radian", Font.PLAIN, 24));
		nombrePista.setBounds(41, 315, 318, 49);
		contentPane.add(nombrePista);
		
		usuario.setBounds(300, 350, 24, 23);
		contentPane.add(usuario);
		
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.setBounds(466, 111, 380, 40);
		contentPane.add(comboBox);
		comboBox.addItem("9:00 - 10:00");
		comboBox.addItem("10:00 - 11:00");
		comboBox.addItem("11:00 - 12:00");
		comboBox.addItem("12:00 - 13:00");
		comboBox.addItem("13:00 - 14:00");
		comboBox.addItem("14:00 - 15:00");
		comboBox.addItem("15:00 - 16:00");
		comboBox.addItem("16:00 - 17:00");
		comboBox.addItem("17:00 - 18:00");
		comboBox.addItem("18:00 - 19:00");
		comboBox.addItem("19:00 - 20:00");
		comboBox.addItem("20:00 - 21:00");
		
		for(int i=0; i<horasReservadas.size();i++){
			comboBox.removeItem(horasReservadas.get(i));
		}
		
		JButton btnNewButton = new JButton("Confirmar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String sql = "INSERT INTO reservas (hora_reserva, id_pista, nick) VALUES (?, ?, ?)";
				Login log = new Login();
				MySQL mysql = new MySQL();
				PreparedStatement statement;
				try {
					statement = MySQL.con.prepareStatement(sql);
					statement.setString(1, comboBox.getSelectedItem().toString());
					statement.setString(2, nombrePista.getText());
					statement.setString(3, usuario.getText());
					
					int rowsInserted = statement.executeUpdate();
					if (rowsInserted > 0) {
					    System.out.println("A new user was inserted successfully!");
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "Su reserva fue realizada con �xito","",JOptionPane.INFORMATION_MESSAGE);
				log.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(553, 315, 199, 40);
		contentPane.add(btnNewButton);
	}
}
