import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblNombre;
	private JLabel lblPrimerApellido;
	private JTextField textField_2;
	private JLabel lblSegundoApellido;
	private JTextField textField_3;
	private JLabel lblCorreoElectrnico;
	private JTextField textField_4;
	private JLabel lblCorreoElectrnico_2;
	private JTextField textField_5;
	private JLabel lblCorreoElectrnico_1;
	private JTextField textField_6;
	private JLabel lblNewLabel_1;
	private JButton btnNewButton;
	private JLabel lblNewLabel_2;
	private JPasswordField passwordField;
	private JLabel lblCorreoElectrnico_3;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		
		 ArrayList<String> nicks = new ArrayList<String>();
		 
			Conexion conexion = new Conexion();
			Connection con = null;
			Statement stm = null;
			ResultSet rs = null;
		
			try {
			con = conexion.conectar();
			stm = con.createStatement();
			rs = stm.executeQuery("SELECT * FROM usuarios");
			
			while(rs.next()) {
				nicks.add(rs.getString(1));
			}
			
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			
			System.out.println(nicks);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 571, 640);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 153, 51));
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Usario:");
		lblNewLabel.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(69, 167, 167, 31);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(229, 171, 249, 31);
		contentPane.add(textField);
		
		lblNombre = new JLabel("Contrase\u00F1a:");
		lblNombre.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblNombre.setBackground(Color.WHITE);
		lblNombre.setBounds(69, 208, 167, 31);
		contentPane.add(lblNombre);
		
		lblPrimerApellido = new JLabel("Nombre:");
		lblPrimerApellido.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblPrimerApellido.setBackground(Color.WHITE);
		lblPrimerApellido.setBounds(69, 249, 167, 31);
		contentPane.add(lblPrimerApellido);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(229, 253, 249, 31);
		contentPane.add(textField_2);
		
		lblSegundoApellido = new JLabel("Primer apellido:");
		lblSegundoApellido.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblSegundoApellido.setBackground(Color.WHITE);
		lblSegundoApellido.setBounds(69, 290, 167, 31);
		contentPane.add(lblSegundoApellido);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(229, 290, 249, 31);
		contentPane.add(textField_3);
		
		lblCorreoElectrnico = new JLabel("Segundo apellido:");
		lblCorreoElectrnico.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblCorreoElectrnico.setBackground(Color.WHITE);
		lblCorreoElectrnico.setBounds(69, 331, 167, 31);
		contentPane.add(lblCorreoElectrnico);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(229, 331, 249, 31);
		contentPane.add(textField_4);
		
		lblCorreoElectrnico_2 = new JLabel("Correo electr\u00F3nico:");
		lblCorreoElectrnico_2.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblCorreoElectrnico_2.setBackground(Color.WHITE);
		lblCorreoElectrnico_2.setBounds(69, 372, 167, 31);
		contentPane.add(lblCorreoElectrnico_2);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(229, 372, 249, 31);
		contentPane.add(textField_5);
		
		lblCorreoElectrnico_1 = new JLabel("Ciudad:");
		lblCorreoElectrnico_1.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblCorreoElectrnico_1.setBackground(Color.WHITE);
		lblCorreoElectrnico_1.setBounds(69, 413, 167, 31);
		contentPane.add(lblCorreoElectrnico_1);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(229, 413, 249, 31);
		contentPane.add(textField_6);
		
		lblNewLabel_1 = new JLabel("CREAR UNA");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Radian", Font.BOLD, 42));
		lblNewLabel_1.setBounds(35, 27, 522, 53);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(424, -24, 177, 140);
		contentPane.add(lblNewLabel_1);
		ImageIcon img1 = new ImageIcon(this.getClass().getResource("LogoDavidSanchez.png"));
		lblNewLabel_1.setIcon(img1);
		
		lblNewLabel_2 = new JLabel("NUEVA CUENTA");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Radian", Font.BOLD, 42));
		lblNewLabel_2.setBounds(35, 79, 522, 53);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(229, 212, 249, 31);
		contentPane.add(passwordField);	
		
		lblCorreoElectrnico_3 = new JLabel("Tel\u00E9fono:");
		lblCorreoElectrnico_3.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblCorreoElectrnico_3.setBackground(Color.WHITE);
		lblCorreoElectrnico_3.setBounds(69, 454, 167, 31);
		contentPane.add(lblCorreoElectrnico_3);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(229, 454, 249, 31);
		contentPane.add(textField_1);
		
		
		btnNewButton = new JButton("Confirmar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				String nickEscrito = textField.getText();
				boolean nickInvalido = false;
				boolean campoVacio = false;
				
				if(textField.getText().equals("") || textField_1.getText().equals("") || textField_2.getText().equals("") || textField_3.getText().equals("") || textField_4.getText().equals("") || textField_5.getText().equals("") || textField_6.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Alg�n campo no ha sido rellenado","",JOptionPane.ERROR_MESSAGE);
					campoVacio = true;
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");
					textField_6.setText("");
					passwordField.setText("");
				}
				
				for(int i=0; i<nicks.size();i++) {
					if(nickEscrito.equals(nicks.get(i))) {
						JOptionPane.showMessageDialog(null, "El nombre de usuario escogido ya est� en uso","",JOptionPane.ERROR_MESSAGE);
						nickInvalido = true;
						textField.setText("");
						textField_1.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
						textField_5.setText("");
						textField_6.setText("");
						passwordField.setText("");
					}
				}
				
				if(nickInvalido == false && campoVacio == false) {
					JOptionPane.showMessageDialog(null, "Su cuenta fue creada con �xito","",JOptionPane.INFORMATION_MESSAGE);
					Login log = new Login();
					log.nuevoNick = nickEscrito;
					log.nuevaPassword = String.valueOf(passwordField.getPassword());
					
					try {
						String sql = "INSERT INTO usuarios (nick, contrase�a, nombre, apellido1, apellido2, ciudad, email, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
						
						MySQL mysql = new MySQL();
						PreparedStatement statement = MySQL.con.prepareStatement(sql);
						statement.setString(1, textField.getText());
						statement.setString(2, String.valueOf(passwordField.getPassword()));
						statement.setString(3, textField_2.getText());
						statement.setString(4, textField_3.getText());
						statement.setString(5, textField_4.getText());
						statement.setString(6, textField_6.getText());
						statement.setString(7, textField_5.getText());
						statement.setString(8, textField_1.getText());
						 
						int rowsInserted = statement.executeUpdate();
						

						
						
					} catch (SQLException e1) {
						
						e1.printStackTrace();
					}
					System.exit(1);
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(192, 526, 158, 45);
		contentPane.add(btnNewButton);
		
	}
}

