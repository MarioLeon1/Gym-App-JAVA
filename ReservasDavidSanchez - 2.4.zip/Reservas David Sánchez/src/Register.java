import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblNombre;
	private JLabel lblPrimerApellido;
	private JTextField textField_2;
	private JLabel lblSegundoApellido;
	private JTextField textField_3;
	private JLabel lblCorreoElectrnico;
	private JTextField textField_4;
	private JLabel lblCorreoElectrnico_2;
	private JTextField textField_5;
	private JLabel lblCorreoElectrnico_1;
	private JTextField textField_6;
	private JLabel lblNewLabel_1;
	private JButton btnNewButton;
	private JLabel lblNewLabel_2;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		
		 ArrayList<String> nicks = new ArrayList<String>();
		 
			Conexion conexion = new Conexion();
			Connection con = null;
			Statement stm = null;
			ResultSet rs = null;
		
			try {
			con = conexion.conectar();
			stm = con.createStatement();
			rs = stm.executeQuery("SELECT * FROM usuarios");
			
			while(rs.next()) {
				nicks.add(rs.getString(1));
			}
			
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
			
			System.out.println(nicks);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 571, 603);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 153, 51));
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Usario:");
		lblNewLabel.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(69, 179, 167, 31);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(229, 183, 249, 31);
		contentPane.add(textField);
		
		lblNombre = new JLabel("Contrase\u00F1a:");
		lblNombre.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblNombre.setBackground(Color.WHITE);
		lblNombre.setBounds(69, 220, 167, 31);
		contentPane.add(lblNombre);
		
		lblPrimerApellido = new JLabel("Nombre:");
		lblPrimerApellido.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblPrimerApellido.setBackground(Color.WHITE);
		lblPrimerApellido.setBounds(69, 261, 167, 31);
		contentPane.add(lblPrimerApellido);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(229, 265, 249, 31);
		contentPane.add(textField_2);
		
		lblSegundoApellido = new JLabel("Primer apellido:");
		lblSegundoApellido.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblSegundoApellido.setBackground(Color.WHITE);
		lblSegundoApellido.setBounds(69, 302, 167, 31);
		contentPane.add(lblSegundoApellido);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(229, 302, 249, 31);
		contentPane.add(textField_3);
		
		lblCorreoElectrnico = new JLabel("Segundo apellido:");
		lblCorreoElectrnico.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblCorreoElectrnico.setBackground(Color.WHITE);
		lblCorreoElectrnico.setBounds(69, 343, 167, 31);
		contentPane.add(lblCorreoElectrnico);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(229, 343, 249, 31);
		contentPane.add(textField_4);
		
		lblCorreoElectrnico_2 = new JLabel("Correo electr\u00F3nico:");
		lblCorreoElectrnico_2.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblCorreoElectrnico_2.setBackground(Color.WHITE);
		lblCorreoElectrnico_2.setBounds(69, 384, 167, 31);
		contentPane.add(lblCorreoElectrnico_2);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(229, 384, 249, 31);
		contentPane.add(textField_5);
		
		lblCorreoElectrnico_1 = new JLabel("Ciudad:");
		lblCorreoElectrnico_1.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblCorreoElectrnico_1.setBackground(Color.WHITE);
		lblCorreoElectrnico_1.setBounds(69, 425, 167, 31);
		contentPane.add(lblCorreoElectrnico_1);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(229, 425, 249, 31);
		contentPane.add(textField_6);
		
		lblNewLabel_1 = new JLabel("CREAR UNA");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Radian", Font.BOLD, 42));
		lblNewLabel_1.setBounds(35, 27, 522, 53);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(424, -24, 177, 140);
		contentPane.add(lblNewLabel_1);
		ImageIcon img1 = new ImageIcon(this.getClass().getResource("LogoDavidSanchez.png"));
		lblNewLabel_1.setIcon(img1);
		
		lblNewLabel_2 = new JLabel("NUEVA CUENTA");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Radian", Font.BOLD, 42));
		lblNewLabel_2.setBounds(35, 79, 522, 53);
		contentPane.add(lblNewLabel_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(229, 224, 249, 31);
		contentPane.add(passwordField);	
		
		
		btnNewButton = new JButton("Confirmar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				String nickEscrito = textField.getText();
				boolean nickInvalido = false;
				
				for(int i=0; i<nicks.size();i++) {
					if(nickEscrito.equals(nicks.get(i))) {
						JOptionPane.showMessageDialog(null, "El nombre de usuario escogido ya est� en uso","",JOptionPane.ERROR_MESSAGE);
						nickInvalido = true;
						textField.setText("");
						textField_2.setText("");
						textField_3.setText("");
						textField_4.setText("");
						textField_5.setText("");
						textField_6.setText("");
						passwordField.setText("");
					}
				}
				
				if(nickInvalido == false) {
					JOptionPane.showMessageDialog(null, "Su cuenta fue creada con �xito","",JOptionPane.INFORMATION_MESSAGE);
					Login log = new Login();
					log.nuevoNick = nickEscrito;
					log.nuevaPassword = String.valueOf(passwordField.getPassword());
					log.setVisible(true);
					dispose();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(192, 493, 158, 45);
		contentPane.add(btnNewButton);
		
	}
}

