import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Autentificado extends JFrame {

	JPanel contentPane;
	JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblPistasDisponibles;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Autentificado frame = new Autentificado();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Autentificado() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 877, 855);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 153, 51));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel();
		lblNewLabel.setText("Bienvenido, Mario");
		lblNewLabel.setFont(new Font("Verdana Pro Cond Light", Font.PLAIN, 33));
		lblNewLabel.setBounds(53, 0, 349, 130);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Cerrar sesi\u00F3n");
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(1);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnNewButton.setBounds(698, 91, 124, 39);
		contentPane.add(btnNewButton);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 149, 434, 276);
		contentPane.add(lblNewLabel_1);
		ImageIcon img1 = new ImageIcon(this.getClass().getResource("PistaTenis.png"));
		lblNewLabel_1.setIcon(img1);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(405, 149, 434, 276);
		contentPane.add(lblNewLabel_2);
		ImageIcon img2 = new ImageIcon(this.getClass().getResource("PistaFutebol.png"));
		lblNewLabel_2.setIcon(img2);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setBounds(0, 483, 434, 276);
		contentPane.add(lblNewLabel_3);
		ImageIcon img3 = new ImageIcon(this.getClass().getResource("PistaAtletismo.png"));
		lblNewLabel_3.setIcon(img3);
		
		lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setBounds(405, 483, 434, 276);
		contentPane.add(lblNewLabel_4);
		ImageIcon img4 = new ImageIcon(this.getClass().getResource("SalaFitness.png"));
		lblNewLabel_4.setIcon(img4);
		
		lblPistasDisponibles = new JLabel();
		lblPistasDisponibles.setForeground(Color.WHITE);
		lblPistasDisponibles.setText("Pistas disponibles:");
		lblPistasDisponibles.setFont(new Font("Verdana Pro Cond Light", Font.PLAIN, 33));
		lblPistasDisponibles.setBounds(53, 45, 349, 130);
		contentPane.add(lblPistasDisponibles);
		
		lblNewLabel_5 = new JLabel("Pista de Tenis");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("Radian", Font.PLAIN, 24));
		lblNewLabel_5.setBounds(31, 397, 318, 49);
		contentPane.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("Pista de F\u00FAtbol");
		lblNewLabel_6.setForeground(Color.WHITE);
		lblNewLabel_6.setFont(new Font("Radian", Font.PLAIN, 24));
		lblNewLabel_6.setBounds(439, 397, 318, 49);
		contentPane.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("Pista de Atletismo");
		lblNewLabel_7.setForeground(Color.WHITE);
		lblNewLabel_7.setFont(new Font("Radian", Font.PLAIN, 24));
		lblNewLabel_7.setBounds(31, 726, 318, 49);
		contentPane.add(lblNewLabel_7);
		
		lblNewLabel_8 = new JLabel("Sala Fitness");
		lblNewLabel_8.setForeground(Color.WHITE);
		lblNewLabel_8.setFont(new Font("Radian", Font.PLAIN, 24));
		lblNewLabel_8.setBounds(439, 726, 318, 49);
		contentPane.add(lblNewLabel_8);
		
		JButton btnCuenta = new JButton("Cuenta");
		btnCuenta.setBackground(Color.WHITE);
		btnCuenta.setFont(new Font("Tahoma", Font.ITALIC, 14));
		btnCuenta.setBounds(698, 53, 124, 39);
		contentPane.add(btnCuenta);
	}
}
