import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 571, 585);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 153, 51));
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nombre de usuario:");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblNewLabel.setBounds(78, 216, 167, 31);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(238, 220, 249, 31);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
		lblContrasea.setFont(new Font("Verdana Pro Cond Light", Font.ITALIC, 18));
		lblContrasea.setBackground(Color.WHITE);
		lblContrasea.setBounds(135, 286, 200, 31);
		contentPane.add(lblContrasea);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(238, 289, 249, 31);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Iniciar Sesi\u00F3n");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String usuario = textField.getText();
				Autentificado aut = new Autentificado();
				aut.lblNewLabel.setText("Bienvenido, "+usuario);
				aut.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.ITALIC, 16));
		btnNewButton.setBounds(205, 354, 158, 45);
		contentPane.add(btnNewButton);
		
		JLabel lblnoTienesUna = new JLabel("\u00BFA\u00FAn no tienes una cuenta?");
		lblnoTienesUna.setFont(new Font("Verdana Pro Cond", Font.ITALIC, 16));
		lblnoTienesUna.setBackground(Color.WHITE);
		lblnoTienesUna.setBounds(178, 437, 321, 31);
		contentPane.add(lblnoTienesUna);
		
		JButton btnRegstrate = new JButton("Reg\u00EDstrate!");
		btnRegstrate.setFont(new Font("Tahoma", Font.ITALIC, 16));
		btnRegstrate.setBounds(212, 478, 134, 31);
		contentPane.add(btnRegstrate);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(70, 44, 177, 140);
		contentPane.add(lblNewLabel_1);
		ImageIcon img1 = new ImageIcon(this.getClass().getResource("LogoDavidSanchez.png"));
		lblNewLabel_1.setIcon(img1);
		
		JLabel lblNewLabel_2 = new JLabel("DAVID");
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Radian", Font.BOLD, 42));
		lblNewLabel_2.setBounds(257, 44, 208, 53);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("S\u00C1NCHEZ");
		lblNewLabel_2_1.setForeground(Color.WHITE);
		lblNewLabel_2_1.setFont(new Font("Radian", Font.BOLD, 42));
		lblNewLabel_2_1.setBounds(255, 92, 208, 45);
		contentPane.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("Polideportivos");
		lblNewLabel_2_1_1.setBackground(Color.BLACK);
		lblNewLabel_2_1_1.setForeground(Color.WHITE);
		lblNewLabel_2_1_1.setFont(new Font("Radian", Font.ITALIC, 20));
		lblNewLabel_2_1_1.setBounds(254, 127, 222, 45);
		contentPane.add(lblNewLabel_2_1_1);
	}
}
